console.log('BX話術腳本已加載');

// 確認目標元素是否存在，並綁定點擊事件
const checkAndBindEvents = () => {
    const target = document.querySelector('.bx-messenger-textarea');
    if (target) {
        if (!target.dataset.bound) {
            console.log('找到目標元素:', target);
            target.dataset.bound = 'true';

            // 動態插入漂浮按鈕容器
            insertFloatingButtons(target);
        } else {
            console.log('目標元素已綁定，跳過重複操作');
        }
    } else {
        console.log('目標元素尚未出現');
    }
};

// 動態插入漂浮的按鈕容器
const insertFloatingButtons = (textareaElement) => {
    const buttonContainer = document.createElement('div');
    buttonContainer.className = 'custom-button-container';
    buttonContainer.style.position = 'absolute'; // 定位相對於父容器
    buttonContainer.style.bottom = '35px'; // 位於文本框上方 10px
    buttonContainer.style.left = '5px';
    buttonContainer.style.width = 'fit-content';
    buttonContainer.style.zIndex = '260';
    buttonContainer.style.backgroundColor = 'rgb(156 148 219)';
    buttonContainer.style.boxShadow = '0px 4px 6px rgba(0, 0, 0, 0.1)';
    buttonContainer.style.borderRadius = '8px';
    buttonContainer.style.padding = '3px';
    buttonContainer.style.display = 'flex';
    buttonContainer.style.flexWrap = 'wrap';
    buttonContainer.style.gap = '3px';
    buttonContainer.style.transition = 'max-height 0.3s ease-in-out'; // 添加展開/收合動畫
    buttonContainer.style.maxHeight = '28px'; // 初始展開高度
	buttonContainer.style.alignItems = 'center';

    // 初始化展開狀態
    let isExpanded = true;

    // 燈泡作為收合開關
	const toggleButton = document.createElement('div');
	toggleButton.className = 'toggle-button';
	toggleButton.style.width = '24px';
	toggleButton.style.height = '24px';
	toggleButton.style.borderRadius = '50%';
	toggleButton.style.border = '1px solid #ccc';
	toggleButton.style.display = 'flex';
	toggleButton.style.alignItems = 'center';
	toggleButton.style.justifyContent = 'center';
	toggleButton.style.backgroundColor = '#fffdd0';
	toggleButton.style.cursor = 'pointer';
	toggleButton.innerText = '💡';
	toggleButton.style.transition = 'box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out';

	// 初始化內發光效果（開燈狀態）
	toggleButton.style.boxShadow = '0 0 10px rgba(255, 255, 0, 0.8)';
	toggleButton.style.backgroundColor = '#fffdd0'; // 開燈背景色

	toggleButton.addEventListener('mouseover', () => {
		toggleButton.style.transform = 'scale(1.2)'; // 放大效果
	});
	toggleButton.addEventListener('mouseout', () => {
		toggleButton.style.transform = 'scale(1)';
	});
	 

    // 初始燈泡效果樣式（開燈狀態）
    toggleButton.style.boxShadow = '0 0 10px rgba(255, 255, 0, 0.8)';

// 禁止雙擊文字選取
toggleButton.addEventListener('dblclick', (e) => {
    e.preventDefault();
    e.stopPropagation();
});

// 節流機制防止快速重複觸發
let isThrottling = false;

toggleButton.addEventListener('click', () => {
    isExpanded = !isExpanded;

	if (isExpanded) {
		// 展開狀態 -> 開燈
		buttonContainer.style.maxWidth = 'fit-content';
		buttonContainer.style.maxHeight = '26px';
		buttonContainer.style.opacity = '1';
		buttonContainer.style.overflow = 'visible';
		toggleButton.style.boxShadow = '0 0 10px rgba(255, 255, 0, 0.8)';
		toggleButton.style.backgroundColor = '#fffdd0'; // 開燈背景色

		// 顯示所有話術按鈕
		Array.from(buttonContainer.children).forEach((child) => {
			if (child !== toggleButton) {
				child.style.visibility = 'visible';
			}
		});
	} else {
		// 收合狀態 -> 關燈
		buttonContainer.style.maxWidth = '26px';
		buttonContainer.style.maxHeight = '26px';
		buttonContainer.style.opacity = '1';
		buttonContainer.style.overflow = 'hidden';
		toggleButton.style.boxShadow = 'inset 0 0 5px rgba(0, 0, 0, 0.4)';
		toggleButton.style.backgroundColor = '#f0f0f0'; // 關燈背景色

		// 隱藏所有話術按鈕
		Array.from(buttonContainer.children).forEach((child) => {
			if (child !== toggleButton) {
				child.style.visibility = 'hidden';
			}
		});
	}

    // 在點擊後強制清除選取範圍
    if (window.getSelection) {
        window.getSelection().removeAllRanges();
    } else if (document.selection) {
        document.selection.empty();
    }
});

toggleButton.addEventListener('mousedown', (e) => {
    e.preventDefault(); // 防止拖動選取文字
});

toggleButton.addEventListener('mouseup', (e) => {
    // 鼠標釋放後清除選取
    if (window.getSelection) {
        window.getSelection().removeAllRanges();
    }
});

toggleButton.addEventListener('dblclick', (e) => {
    e.preventDefault(); // 禁止雙擊選取文字
    if (window.getSelection) {
        window.getSelection().removeAllRanges();
    }
});

    buttonContainer.appendChild(toggleButton);

    // 動態生成功能按鈕
    const buttons = [
        { text: '小幫手❤️', message: '您好，這裡是客服小幫手❤️' },
        { text: '什麼協助？', message: '請問有什麼需要協助的地方呢？' },
        { text: '確認中', message: '收到，我們確認一下，請稍候！' },
        { text: '導入↙️', message: '家長您好，感謝您主動提供資訊🙏\n\n稍後將替您加入專屬老師到此聊天室，如對孩子的學習有任何想法，都歡迎您在此聊天室告訴我們，謝謝您😊' },
        { text: '🤫', message: '顧問組長您好~  導入流程調整為在客服協助合併客戶BX聯絡人後，【務必由您自行將被分派的組員加入此聊天室】，謝謝您。 ' },
        { text: '轉給輔導', message: '小幫手已接收到您的訊息，稍後會將訊息轉達給輔導老師哦！' },
        { text: '不客氣', message: '不客氣，若有其他問題、歡迎請再留言給小幫手，祝您順心😊' },
        { text: '10分', message: '您好，因超過10分鐘未收到您的訊息，系統將自動關閉視窗，若有問題再煩請來訊，謝謝您。' },
        { text: '生生📖', message: '您好：\n\n因應「生生用平板」政策，受限於相關法令，目前電子書系統僅提供學校教師使用。\n\n教育部積極推動數位學習發展，並依智慧財產權法規對數位資源的使用資格加以限制。自2022年9月20日（星期二）起，南一書局相關課程數位資源及NaniBook電子書連結，僅限以「教師身分」登入後方可使用。\n\n若家長有學用電子書需求，建議向學校班級導師詢問（依學校採購情況而定）；亦可加入OneClass線上家教，安排免費教育諮詢。\n\n歡迎加入OneClass的專屬Line@頻道（@oneclass123），了解更多服務內容。' }
    ];

	buttons.forEach((button) => {
		const clickableDiv = document.createElement('div');
		clickableDiv.innerText = button.text;
		clickableDiv.style.cursor = 'pointer';
		clickableDiv.style.display = 'inline-block';
		clickableDiv.style.border = '1px solid #ccc';
		clickableDiv.style.borderRadius = '5px';
		clickableDiv.style.backgroundColor = '#f0f0f0';
		clickableDiv.style.color = '#000';
		clickableDiv.style.fontSize = '10pt';
		clickableDiv.style.height = '20px'; // 設定高度
		clickableDiv.style.lineHeight = '20px'; // 垂直居中
		clickableDiv.style.padding = '2px 4px';

		// 添加 title 屬性
		clickableDiv.title = button.message;

		clickableDiv.onclick = () => {
			const inputField = document.querySelector('.bx-messenger-textarea-input');
			if (inputField) {
				inputField.value = button.message;
				inputField.focus();
			} else {
				console.error('無法找到輸入欄位');
			}
		};
		buttonContainer.appendChild(clickableDiv);
	});

    // 將按鈕容器插入到 bx-messenger-textarea 的父元素中
    textareaElement.parentElement.style.position = 'relative'; // 確保相對定位
    textareaElement.parentElement.appendChild(buttonContainer);
};

// 動態監控 DOM 變化
const observer = new MutationObserver((mutations) => {
    const significantMutation = mutations.some(
        (mutation) => mutation.type === 'childList' && mutation.addedNodes.length > 0
    );
    if (significantMutation) {
        checkAndBindEvents();
    }
});

observer.observe(document.body, { childList: true, subtree: true });
checkAndBindEvents();