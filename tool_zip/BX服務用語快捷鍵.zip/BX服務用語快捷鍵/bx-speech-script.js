// ===== Google Sheet 設定與工具 =====
const BX_SHEETID_KEY = 'bxSheetId';
const BX_SHEET_CACHE_KEY = 'bxSheet';
const BX_SHEET_CACHE_TIME_KEY = 'bxSheetTime';
const BX_SHEET_CACHE_MS = 6 * 60 * 60 * 1000; // 6 小時

function getSheetId() {
  return new Promise(res => {
	chrome.storage.local.get([BX_SHEETID_KEY], r => {
	  res(r[BX_SHEETID_KEY] || ''); // 沒有就回傳空字串
	});
  });
}

function setSheetId(sheetId) {
  return new Promise(res => {
	chrome.storage.local.set({ [BX_SHEETID_KEY]: sheetId }, res);
  });
}

async function loadSheet() {
  const sheetId = await getSheetId();
  const url = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`;
  const now = Date.now();
  const cache = await new Promise(res => chrome.storage.local.get([BX_SHEET_CACHE_KEY, BX_SHEET_CACHE_TIME_KEY, BX_SHEETID_KEY], res));
  if (
	cache[BX_SHEET_CACHE_KEY] &&
	cache[BX_SHEET_CACHE_TIME_KEY] &&
	cache[BX_SHEETID_KEY] === sheetId &&
	(now - cache[BX_SHEET_CACHE_TIME_KEY] < BX_SHEET_CACHE_MS)
  ) {
	return cache[BX_SHEET_CACHE_KEY];
  }
  try {
	const resp = await fetch(url);
	if (!resp.ok) throw new Error('fetch failed');
	const csv = await resp.text();
	// 存原始 csv 首列到全域，供 toggleButton 用
	window.BX_SHEET_RAW_CSV = csv;
	const data = parseCsv(csv);
	await cacheSheet(data, sheetId);
	return data;
  } catch (e) {
	if (cache[BX_SHEET_CACHE_KEY]) return cache[BX_SHEET_CACHE_KEY];
	return [];
  }
}

function parseCsv(csvText) {
  // 支援多行欄位（RFC4180），處理換行與引號
  const lines = csvText.split(/\r?\n/);
  if (lines.length < 1) return [];
  const result = [];
  let row = [];
  let inQuotes = false;
  let field = '';
  for (let i = 0; i < lines.length; ++i) { // 不跳過任何一列，無標題列
	let line = lines[i];
	if (line === undefined) continue;
	let j = 0;
	while (j < line.length) {
	  const char = line[j];
	  if (char === '"') {
		if (inQuotes && line[j + 1] === '"') {
		  field += '"';
		  j += 2;
		} else {
		  inQuotes = !inQuotes;
		  j++;
		}
	  } else if (char === ',' && !inQuotes) {
		row.push(field);
		field = '';
		j++;
	  } else {
		field += char;
		j++;
	  }
	}
	if (inQuotes) {
	  field += '\n';
	  continue;
	}
	row.push(field);
	if (row.length >= 2) {
	  result.push({
		text: row[0],
		message: row[1],
		showOnCollapsed: (row[2] && row[2][0] === '1')
	  });
	}
	row = [];
	field = '';
	inQuotes = false;
  }
  return result;
}

async function cacheSheet(data, sheetId) {
  return new Promise(res => chrome.storage.local.set({ [BX_SHEET_CACHE_KEY]: data, [BX_SHEET_CACHE_TIME_KEY]: Date.now(), [BX_SHEETID_KEY]: sheetId }, res));
}

function scheduleSheetRefresh() {
  if (chrome.alarms) {
	chrome.alarms.create('bxSheetRefresh', { periodInMinutes: 360 });
	chrome.alarms.onAlarm.addListener(alarm => {
	  if (alarm.name === 'bxSheetRefresh') loadSheet();
	});
  }
}
console.log('BX話術腳本已加載');

// 確認目標元素是否存在，並綁定點擊事件
const checkAndBindEvents = () => {
	const target = document.querySelector('.bx-messenger-textarea');
	if (target) {
		if (!target.dataset.bound) {
			console.log('找到目標元素:', target);
			target.dataset.bound = 'true';

			// 動態插入漂浮按鈕容器
			insertFloatingButtons(target);
		} else {
			console.log('目標元素已綁定，跳過重複操作');
		}
	} else {
		console.log('目標元素尚未出現');
	}
};

// 展開/收合狀態全域管理
const BX_EXPANDED_KEY = 'bxIsExpanded';
if (typeof window.BX_IS_EXPANDED === 'undefined') {
  try {
	const stored = localStorage.getItem(BX_EXPANDED_KEY);
	if (stored === '0') window.BX_IS_EXPANDED = false;
	else window.BX_IS_EXPANDED = true;
  } catch { window.BX_IS_EXPANDED = true; }
}
function getIsExpanded() { return !!window.BX_IS_EXPANDED; }
function setIsExpanded(val) {
  window.BX_IS_EXPANDED = !!val;
  try { localStorage.setItem(BX_EXPANDED_KEY, val ? '1' : '0'); } catch {}
}

const insertFloatingButtons = async (textareaElement) => {
  // 檢查是否有 Sheet ID，若無則強制要求輸入
  let sheetId = await getSheetId();
  while (!sheetId) {
	const input = prompt('請輸入 Google Sheet 文件ID：');
	if (input && input.trim()) {
	  sheetId = input.trim();
	  await setSheetId(sheetId);
	}
  }

  // 只允許同時存在一個 buttonContainer
  let old = document.querySelector('.custom-button-container');
  if (old) old.remove();

  const buttonContainer = document.createElement('div');
  buttonContainer.className = 'custom-button-container';
  buttonContainer.style.position = 'fixed'; // 固定於 viewport
  buttonContainer.style.left = '10px'; // 初始位置
  buttonContainer.style.top = '10px';
  buttonContainer.style.width = 'fit-content';
  buttonContainer.style.zIndex = '50';
  // 讀取自訂底色
  const BX_BG_COLOR_KEY = 'bxCustomBtnBgColor';
  let customBgColor = localStorage.getItem(BX_BG_COLOR_KEY);
  if (!customBgColor) customBgColor = 'rgba(156, 148, 219, 0.4)';
  buttonContainer.style.backgroundColor = customBgColor;
  buttonContainer.style.boxShadow = '0px 4px 6px rgba(0, 0, 0, 0.1)';
  buttonContainer.style.borderRadius = '20px';
  buttonContainer.style.padding = '8px 19px 8px 19px';
  buttonContainer.style.display = 'flex';
  buttonContainer.style.flexWrap = 'wrap';
  buttonContainer.style.gap = '3px';
  buttonContainer.style.transition = 'max-height 0.3s ease-in-out'; // 添加展開/收合動畫
  buttonContainer.style.maxHeight = '30px'; // 初始展開高度
  buttonContainer.style.alignItems = 'center';
  buttonContainer.style.backdropFilter = 'blur(1px) sepia(0.8) hue-rotate(268deg)';
  buttonContainer.style.webkitBackdropFilter = 'blur(1px) sepia(0.8) hue-rotate(268deg)'; // for Safari
  buttonContainer.style.userSelect = 'none';
  buttonContainer.style.webkitUserSelect = 'none';
  buttonContainer.style.MozUserSelect = 'none';
  buttonContainer.style.msUserSelect = 'none';

	// a11y
	buttonContainer.setAttribute('role', 'region');
	buttonContainer.setAttribute('aria-label', '快捷話術按鈕');
	buttonContainer.setAttribute('tabindex', '0');

	// 拖曳狀態
	let bxDragActive = false;
	let bxDragEdge = null; // 'top' | 'bottom' | 'left' | 'right' | null
	let bxDragOffset = { x: 0, y: 0 };
	let bxDragLock = null; // 'x' | 'y' | null
	const BX_DRAG_EDGE_WIDTH = 18;
	const BX_POS_KEY = 'bxCustomBtnPos';

	// 讀取持久化位置
	const restoreBxPosition = () => {
		try {
			const pos = JSON.parse(localStorage.getItem(BX_POS_KEY));
			if (pos && typeof pos.left === 'number' && typeof pos.top === 'number') {
				buttonContainer.style.left = pos.left + 'px';
				buttonContainer.style.top = pos.top + 'px';
			}
		} catch {}
	};
	restoreBxPosition();

	// 儲存位置
	const persistBxPosition = () => {
		const left = parseInt(buttonContainer.style.left, 10) || 0;
		const top = parseInt(buttonContainer.style.top, 10) || 0;
		localStorage.setItem(BX_POS_KEY, JSON.stringify({ left, top }));
	};

	// 判斷是否在四邊
	function bxIsOnEdge(e, el) {
		const rect = el.getBoundingClientRect();
		let x, y;
		if (e.touches && e.touches.length) {
			x = e.touches[0].clientX - rect.left;
			y = e.touches[0].clientY - rect.top;
		} else {
			x = e.clientX - rect.left;
			y = e.clientY - rect.top;
		}
		if (x < BX_DRAG_EDGE_WIDTH) return 'left';
		if (x > rect.width - BX_DRAG_EDGE_WIDTH) return 'right';
		if (y < BX_DRAG_EDGE_WIDTH) return 'top';
		if (y > rect.height - BX_DRAG_EDGE_WIDTH) return 'bottom';
		return null;
	}

	// 游標提示
	buttonContainer.addEventListener('mousemove', function bxDragCursor(e) {
		const edge = bxIsOnEdge(e, buttonContainer);
		if (edge) {
			buttonContainer.style.cursor = 'move';
		} else {
			buttonContainer.style.cursor = '';
		}
	});

	// 觸控游標提示
	buttonContainer.addEventListener('touchstart', function bxDragTouchCursor(e) {
		const edge = bxIsOnEdge(e, buttonContainer);
		if (edge) {
			buttonContainer.style.cursor = 'move';
		} else {
			buttonContainer.style.cursor = '';
		}
	});

	// 拖曳啟動
	function bxDragStartHandler(e) {
		if (e.button !== undefined && e.button !== 0) return; // 只允許左鍵
		const edge = bxIsOnEdge(e, buttonContainer);
		if (!edge) return;
		bxDragActive = true;
		bxDragEdge = edge;
		bxDragLock = null;
		buttonContainer.setAttribute('aria-grabbed', 'true');
		const rect = buttonContainer.getBoundingClientRect();
		let pointerX, pointerY;
		if (e.touches && e.touches.length) {
			pointerX = e.touches[0].clientX;
			pointerY = e.touches[0].clientY;
		} else {
			pointerX = e.clientX;
			pointerY = e.clientY;
		}
		// 計算 offset 使拖曳時指標與邊緣保持相對位置
		bxDragOffset.x = pointerX - rect.left;
		bxDragOffset.y = pointerY - rect.top;
		document.addEventListener('mousemove', bxDragMoveHandler);
		document.addEventListener('mouseup', bxDragEndHandler);
		document.addEventListener('touchmove', bxDragMoveHandler, { passive: false });
		document.addEventListener('touchend', bxDragEndHandler);
		e.preventDefault();
		e.stopPropagation();
	}
	buttonContainer.addEventListener('mousedown', bxDragStartHandler);
	buttonContainer.addEventListener('touchstart', bxDragStartHandler, { passive: false });

	// 拖曳進行
	function bxDragMoveHandler(e) {
		if (!bxDragActive) return;
		let pointerX, pointerY;
		if (e.touches && e.touches.length) {
			pointerX = e.touches[0].clientX;
			pointerY = e.touches[0].clientY;
		} else {
			pointerX = e.clientX;
			pointerY = e.clientY;
		}
		// 判斷鎖定軸
		if (!e.touches) {
			if (e.shiftKey) {
				bxDragLock = 'x';
			} else if (e.altKey) {
				bxDragLock = 'y';
			} else {
				bxDragLock = null;
			}
		}
		let newLeft = pointerX - bxDragOffset.x;
		let newTop = pointerY - bxDragOffset.y;
		// 邊界限制
		newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - buttonContainer.offsetWidth));
		newTop = Math.max(0, Math.min(newTop, window.innerHeight - buttonContainer.offsetHeight));
		// 軸鎖定
		if (bxDragLock === 'x') {
			// 水平鎖定，top 不變
			newTop = parseInt(buttonContainer.style.top, 10) || 0;
		} else if (bxDragLock === 'y') {
			// 垂直鎖定，left 不變
			newLeft = parseInt(buttonContainer.style.left, 10) || 0;
		}
		buttonContainer.style.left = newLeft + 'px';
		buttonContainer.style.top = newTop + 'px';
		e.preventDefault();
	}

	// 拖曳結束
	function bxDragEndHandler(e) {
		if (!bxDragActive) return;
		bxDragActive = false;
		bxDragEdge = null;
		bxDragLock = null;
		buttonContainer.removeAttribute('aria-grabbed');
		document.removeEventListener('mousemove', bxDragMoveHandler);
		document.removeEventListener('mouseup', bxDragEndHandler);
		document.removeEventListener('touchmove', bxDragMoveHandler);
		document.removeEventListener('touchend', bxDragEndHandler);
		persistBxPosition();
	}

	// 鍵盤拖曳 a11y
	let bxKeyboardDrag = false;
	buttonContainer.addEventListener('keydown', function bxDragKeyHandler(e) {
		if (bxKeyboardDrag) {
			let step = e.shiftKey ? 10 : 2;
			let left = parseInt(buttonContainer.style.left, 10) || 0;
			let top = parseInt(buttonContainer.style.top, 10) || 0;
			if (e.key === 'ArrowLeft') { buttonContainer.style.left = Math.max(0, left - step) + 'px'; persistBxPosition(); e.preventDefault(); }
			if (e.key === 'ArrowRight') { buttonContainer.style.left = (left + step) + 'px'; persistBxPosition(); e.preventDefault(); }
			if (e.key === 'ArrowUp') { buttonContainer.style.top = Math.max(0, top - step) + 'px'; persistBxPosition(); e.preventDefault(); }
			if (e.key === 'ArrowDown') { buttonContainer.style.top = (top + step) + 'px'; persistBxPosition(); e.preventDefault(); }
			if (e.key === 'Escape') { bxKeyboardDrag = false; buttonContainer.removeAttribute('aria-grabbed'); e.preventDefault(); }
		} else {
			if (e.key === ' ' || e.key === 'Enter') {
				bxKeyboardDrag = true;
				buttonContainer.setAttribute('aria-grabbed', 'true');
				e.preventDefault();
			}
		}
	});
	buttonContainer.addEventListener('keyup', function bxDragKeyUp(e) {
		if (bxKeyboardDrag && (e.key === ' ' || e.key === 'Enter')) {
			bxKeyboardDrag = false;
			buttonContainer.removeAttribute('aria-grabbed');
		}
	});




	// 燈泡作為收合開關
	const toggleButton = document.createElement('div');
	toggleButton.className = 'toggle-button';
  toggleButton.style.width = '24px';
  toggleButton.style.height = '24px';
  toggleButton.style.minWidth = '24px';
  toggleButton.style.minHeight = '24px';
  toggleButton.style.maxWidth = '24px';
  toggleButton.style.maxHeight = '24px';
  toggleButton.style.aspectRatio = '1/1';
  // 保持正圓形
  toggleButton.style.borderRadius = '50%';
	toggleButton.style.borderRadius = '50%';
	toggleButton.style.border = '1px solid #ccc';
	toggleButton.style.display = 'flex';
	toggleButton.style.alignItems = 'center';
	toggleButton.style.justifyContent = 'center';
	toggleButton.style.backgroundColor = '#fffdd0';
	toggleButton.style.cursor = 'pointer';
	toggleButton.style.marginRight = '6px';
	toggleButton.style.transition = 'box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out';

	// 初始化內發光效果（開燈狀態）
	toggleButton.style.boxShadow = '0 0 10px rgba(255, 255, 0, 0.8)';
	toggleButton.style.backgroundColor = '#fffdd0'; // 開燈背景色

	toggleButton.addEventListener('mouseover', () => {
		toggleButton.style.transform = 'scale(1.2)'; // 放大效果
	});
	toggleButton.addEventListener('mouseout', () => {
		toggleButton.style.transform = 'scale(1)';
	});
	 

	// 初始燈泡效果樣式（開燈狀態）
	toggleButton.style.boxShadow = '0 0 10px rgba(255, 255, 0, 0.8)';

// 禁止雙擊文字選取
toggleButton.addEventListener('dblclick', (e) => {
	e.preventDefault();
	e.stopPropagation();
});

// 節流機制防止快速重複觸發
let isThrottling = false;

// 已由 robust 全域 toggleButton handler 取代，避免 isExpanded 未定義錯誤

toggleButton.addEventListener('mousedown', (e) => {
	e.preventDefault(); // 防止拖動選取文字
});

toggleButton.addEventListener('mouseup', (e) => {
	// 鼠標釋放後清除選取
	if (window.getSelection) {
		window.getSelection().removeAllRanges();
	}
});

toggleButton.addEventListener('dblclick', (e) => {
	e.preventDefault(); // 禁止雙擊選取文字
	if (window.getSelection) {
		window.getSelection().removeAllRanges();
	}
});

	buttonContainer.appendChild(toggleButton);


  // 動態生成功能按鈕（每次展開都重新撈取）
  let lastSheet = [];
  // 取得 B1 欄位（CSV 第一列第二欄）第一個字元
  let bxToggleSymbol = '💡';
  async function renderButtons(forceReloadSheetId) {
  // 清除舊按鈕（保留 toggleButton 與鉛筆按鈕）
  Array.from(buttonContainer.children).forEach(child => {
	if (child !== toggleButton && !child.classList.contains('bx-edit-btn')) buttonContainer.removeChild(child);
  });
  // robust: 每次都強制同步 toggleButton 內容，避免被覆蓋
  if (typeof toggleButton !== 'undefined' && toggleButton) {
	toggleButton.innerText = bxToggleSymbol;
  }

  let sheet, errorType = null, errorDetail = '';
  // 取得 B1 欄位
  let b1Symbol = '💡';
  try {
	if (forceReloadSheetId) {
	  // 強制用新ID重新撈，並清除快取時間強制重抓
	  await setSheetId(forceReloadSheetId);
	  await new Promise(res => chrome.storage.local.remove([BX_SHEET_CACHE_TIME_KEY, BX_SHEET_CACHE_KEY], res));
	}
	sheet = await loadSheet();
	if (!Array.isArray(sheet) || sheet.length === 0) throw new Error('empty');
	lastSheet = sheet;
	// robust 只取 B1 欄位（首列第二欄，支援引號、emoji、逗號）
  if (window.BX_SHEET_RAW_CSV && typeof window.BX_SHEET_RAW_CSV === 'string') {
  const lines = window.BX_SHEET_RAW_CSV.split(/\r?\n/);
  if (lines.length > 0) {
	// 解析首列，正確取得 B1 欄位（支援引號、emoji、逗號、數字）
	let inQuotes = false, field = '';
	let col = 0;
	let b1 = '';
	const csvLine = lines[0];
	for (let i = 0; i < csvLine.length; ++i) {
	  const char = csvLine[i];
	  if (char === '"') {
		inQuotes = !inQuotes;
	  } else if (char === ',' && !inQuotes) {
		if (col === 1) { b1 = field; break; }
		field = '';
		col++;
	  } else {
		field += char;
	  }
	}
	if (col === 1 && b1 === '') b1 = field; // 若B1在最後
	// robust: 處理 B1 欄位為數字、字串、emoji等
	if (typeof b1 !== 'undefined' && b1 !== null) {
	  b1 = String(b1).trim();
	  if (b1[0] === '"' && b1[b1.length-1] === '"') b1 = b1.slice(1, -1);
	  b1Symbol = b1;
	}
  }
  } else {
	// fallback: 若 parseCsv 沒存 raw csv，則用 💡，並加上 LOG
	b1Symbol = '💡';
	if (sheet && sheet.length > 0 && sheet[0].text && typeof sheet[0].text === 'string') {
	  // LOG fallback 來源
	  console.log('[BX LOG] toggleButton fallback: sheet[0].text =', sheet[0].text, ', sheet[0].message =', sheet[0].message);
	} else {
	  console.log('[BX LOG] toggleButton fallback: 無 sheet 或 sheet[0]');
	}
  }
  } catch (e) {
	sheet = lastSheet;
	if (!sheet || !Array.isArray(sheet) || sheet.length === 0) {
	  errorType = 'no-data';
	  errorDetail = e && e.message ? e.message : '';
	} else {
	  errorType = 'offline';
	  errorDetail = e && e.message ? e.message : '';
	}
	if (e) console.error('[BX話術] Google Sheet 載入失敗:', e);
  }
  // 設定全域 toggle 符號
bxToggleSymbol = (b1Symbol && typeof b1Symbol === 'string' && b1Symbol.trim().length > 0) ? b1Symbol : '💡';

	if (errorType === 'no-data') {
	  // 完全無資料，顯示錯誤提示與鉛筆設定
	  const errorDiv = document.createElement('div');
	  errorDiv.innerHTML = '<span style="color:#fff;background:#e74c3c;padding:2px 8px;border-radius:5px;font-size:11pt;vertical-align:middle;">⚠️ 無法讀取 Google Sheet，請檢查文件ID或權限</span>';
	  errorDiv.style.margin = '0 6px 0 0';
	  errorDiv.style.display = 'inline-block';
	  errorDiv.setAttribute('role', 'alert');
	  errorDiv.setAttribute('tabindex', '0');
	  errorDiv.title = errorDetail ? ('錯誤詳情: ' + errorDetail) : '無法讀取 Google Sheet';

	  // 重試按鈕
	  const retryBtn = document.createElement('button');
	  retryBtn.innerText = '重試';
	  retryBtn.style.marginLeft = '8px';
	  retryBtn.style.background = '#fff';
	  retryBtn.style.cursor = 'pointer';
	  retryBtn.style.fontSize = '10pt';
	  retryBtn.onclick = async (e) => {
		await renderButtons(forceReloadSheetId);
	  };
	  errorDiv.appendChild(retryBtn);

	  // 鉛筆ICON
	  const editBtn = document.createElement('div');
	  editBtn.innerHTML = '✏️';
	  editBtn.style.cursor = 'pointer';
	  editBtn.style.display = 'inline-block';
	  editBtn.style.color = '#000';
	  editBtn.style.fontSize = '14pt';
	  editBtn.style.width = '24px';
	  editBtn.style.height = '24px';
	  editBtn.style.lineHeight = '24px';
	  editBtn.style.textAlign = 'center';
	  editBtn.style.marginLeft = '8px';
	  editBtn.title = '設定 Google Sheet ID';
	  editBtn.onclick = async (e) => {
		const currentId = await getSheetId();
		const newId = prompt('請輸入 Google Sheet 文件ID：', currentId);
		if (newId && newId !== currentId) {
		  await renderButtons(newId);
		}
	  };
	  errorDiv.appendChild(editBtn);

	  buttonContainer.appendChild(errorDiv);
	  return;
	}

  if (sheet && sheet.length > 0) {
	// robust: 再次強制同步 toggleButton 內容
	if (typeof toggleButton !== 'undefined' && toggleButton) {
	  toggleButton.innerText = bxToggleSymbol;
	}
	// 只渲染 index > 0 的資料為罐頭訊息按鈕（第一列只給 toggleButton 用）
	sheet.forEach((button, idx) => {
	  if (idx === 0) return; // 跳過第一列
	  if (!button.text || !button.message) return;
	  const clickableDiv = document.createElement('div');
	  clickableDiv.innerText = button.text;
	  clickableDiv.style.cursor = 'pointer';
	  clickableDiv.style.display = 'inline-block';
	  clickableDiv.style.border = '1px solid #ccc';
	  clickableDiv.style.borderRadius = '5px';
	  clickableDiv.style.backgroundColor = '#f0f0f0';
	  clickableDiv.style.color = '#000';
	  clickableDiv.style.fontSize = '10pt';
	  clickableDiv.style.height = '20px';
	  clickableDiv.style.lineHeight = '20px';
	  clickableDiv.style.padding = '2px 4px';
	  clickableDiv.title = button.message;
	  clickableDiv.dataset.showOnCollapsed = button.showOnCollapsed ? '1' : '0';
	  clickableDiv.onclick = () => {
		const inputField = document.querySelector('.bx-messenger-textarea-input');
		if (inputField) {
		  inputField.value = button.message;
		  inputField.focus();
		} else {
		  console.error('無法找到輸入欄位');
		}
	  };
	  buttonContainer.appendChild(clickableDiv);
	});
  // 只新增一個鉛筆ICON按鈕（最右側，且永遠存在）
  let editBtn = buttonContainer.querySelector('.bx-edit-btn');
  if (!editBtn) {
	editBtn = document.createElement('div');
	editBtn.className = 'bx-edit-btn';
	editBtn.innerHTML = '✏️';
	editBtn.style.cursor = 'pointer';
	editBtn.style.display = 'inline-block';
	editBtn.style.color = '#000';
	editBtn.style.fontSize = '14pt';
	editBtn.style.width = '24px';
	editBtn.style.height = '24px';
	editBtn.style.lineHeight = '24px';
	editBtn.style.textAlign = 'center';
	editBtn.style.marginLeft = '6px';
	editBtn.title = '設定 Google Sheet ID';
  editBtn.onclick = async (e) => {
	e.stopPropagation();
	const currentId = await getSheetId();
	const newId = prompt('請輸入 Google Sheet 文件ID：', currentId);
	console.log('[BX鉛筆] 點擊鉛筆，currentId:', currentId, 'newId:', newId);
	if (newId) {
	  // 不論是否相同都強制重新下載
	  console.log('[BX鉛筆] 送出ID，開始 renderButtons');
	  try {
		await renderButtons(newId);
		console.log('[BX鉛筆] renderButtons 完成，已更新面板');
	  } catch (err) {
		console.error('[BX鉛筆] renderButtons 發生錯誤:', err);
	  }
	} else {
	  console.log('[BX鉛筆] 未送出新ID（取消）');
	}
  };
  // 鉛筆按鈕永遠在最右側
  if (buttonContainer.lastChild !== editBtn) {
	buttonContainer.appendChild(editBtn);
  }
  }

  // 新增調色盤按鈕（最右側，永遠存在）
  let colorBtn = buttonContainer.querySelector('.bx-color-btn');
  let colorWrap;
  if (!colorBtn) {
	// 用一個span包住colorBtn和colorInput，方便定位
	colorWrap = document.createElement('span');
	colorWrap.style.position = 'relative';
	colorWrap.style.display = 'inline-block';

	colorBtn = document.createElement('div');
	colorBtn.className = 'bx-color-btn';
	colorBtn.innerHTML = '🎨';
	colorBtn.style.cursor = 'pointer';
	colorBtn.style.display = 'inline-block';
	colorBtn.style.color = '#000';
	colorBtn.style.fontSize = '14pt';
	colorBtn.style.width = '24px';
	colorBtn.style.height = '24px';
	colorBtn.style.lineHeight = '24px';
	colorBtn.style.textAlign = 'center';
	colorBtn.style.marginLeft = '2px';
	colorBtn.title = '自訂底色 (可用色碼或調色盤)';

	// 建立隱藏的 color picker input
	let colorInput = document.createElement('input');
	colorInput.type = 'color';
	colorInput.style.display = 'none';
	colorInput.style.position = 'absolute';
	colorInput.style.left = '28px'; // 在調色盤icon右側
	colorInput.style.top = '0px';
	colorInput.style.zIndex = '9999';
	colorInput.className = 'bx-color-picker-input';

	// 將目前顏色轉成 hex（如果是 rgba 會 fallback 成預設色）
	function toHexColor(str) {
	  let ctx = document.createElement('canvas').getContext('2d');
	  ctx.fillStyle = str;
	  let hex = ctx.fillStyle;
	  // 若為 transparent 或 rgba 會回傳 rgb(...)，需轉 hex
	  if (hex.startsWith('rgb')) {
		let rgb = hex.match(/\d+/g);
		if (rgb && rgb.length >= 3) {
		  return '#' + ((1 << 24) + (parseInt(rgb[0]) << 16) + (parseInt(rgb[1]) << 8) + parseInt(rgb[2])).toString(16).slice(1);
		}
	  }
	  return hex;
	}

	colorBtn.onclick = (e) => {
	  e.stopPropagation();
	  // 設定 input 顏色
	  let current = localStorage.getItem(BX_BG_COLOR_KEY) || 'rgba(156, 148, 219, 0.4)';
	  colorInput.value = toHexColor(current);
	  colorInput.style.display = 'block';
	  colorInput.focus();
	  colorInput.click();
	};

	// 即時預覽（不儲存）
	colorInput.addEventListener('input', function(e) {
	  let hex = colorInput.value;
	  let r = parseInt(hex.slice(1, 3), 16);
	  let g = parseInt(hex.slice(3, 5), 16);
	  let b = parseInt(hex.slice(5, 7), 16);
	  let rgba = `rgba(${r}, ${g}, ${b}, 0.4)`;
	  buttonContainer.style.backgroundColor = rgba;
	});

	// 只在 change 時儲存
	colorInput.addEventListener('change', function(e) {
	  let hex = colorInput.value;
	  let r = parseInt(hex.slice(1, 3), 16);
	  let g = parseInt(hex.slice(3, 5), 16);
	  let b = parseInt(hex.slice(5, 7), 16);
	  let rgba = `rgba(${r}, ${g}, ${b}, 0.4)`;
	  localStorage.setItem(BX_BG_COLOR_KEY, rgba);
	  buttonContainer.style.backgroundColor = rgba;
	  colorInput.style.display = 'none';
	});

	// 失焦時只隱藏，不儲存
	colorInput.addEventListener('blur', function() {
	  colorInput.style.display = 'none';
	});

	colorWrap.appendChild(colorBtn);
	colorWrap.appendChild(colorInput);
	// 調色盤插入鉛筆左側
	if (buttonContainer.lastChild && buttonContainer.lastChild.classList && buttonContainer.lastChild.classList.contains('bx-edit-btn')) {
	  buttonContainer.insertBefore(colorWrap, buttonContainer.lastChild);
	} else {
	  buttonContainer.appendChild(colorWrap);
	}
  } else {
	// 若已存在，確保在鉛筆左側
	colorWrap = colorBtn.parentNode;
	if (buttonContainer.lastChild && buttonContainer.lastChild.classList && buttonContainer.lastChild.classList.contains('bx-edit-btn')) {
	  if (buttonContainer.lastChild.previousSibling !== colorWrap) {
		buttonContainer.insertBefore(colorWrap, buttonContainer.lastChild);
	  }
	} else if (buttonContainer.lastChild !== colorWrap) {
	  buttonContainer.appendChild(colorWrap);
	}
  }
  // 鉛筆按鈕永遠在最右側
  if (buttonContainer.lastChild !== editBtn) {
	buttonContainer.appendChild(editBtn);
  }

	  // 若為離線模式，顯示提示
	  if (errorType === 'offline') {
		const offlineDiv = document.createElement('div');
		offlineDiv.innerHTML = '<span style="color:#fff;background:#e67e22;padding:2px 8px;border-radius:5px;font-size:10pt;vertical-align:middle;">⚠️ 離線模式，資料可能已過期</span>';
		offlineDiv.style.margin = '0 6px 0 0';
		offlineDiv.style.display = 'inline-block';
		offlineDiv.setAttribute('role', 'status');
		offlineDiv.setAttribute('tabindex', '0');
		offlineDiv.title = errorDetail ? ('錯誤詳情: ' + errorDetail) : '離線模式';
		// 重試按鈕
		const retryBtn = document.createElement('button');
		retryBtn.innerText = '重試';
		retryBtn.style.marginLeft = '8px';
		retryBtn.style.background = '#fff';
		retryBtn.style.color = '#e67e22';
		retryBtn.style.border = '1px solid #e67e22';
		retryBtn.style.borderRadius = '4px';
		retryBtn.style.cursor = 'pointer';
		retryBtn.style.fontSize = '10pt';
		retryBtn.onclick = async (e) => {
		  await renderButtons(forceReloadSheetId);
		};
		offlineDiv.appendChild(retryBtn);
		// 鉛筆按鈕永遠在最右側
		if (buttonContainer.lastChild !== editBtn) {
		  buttonContainer.appendChild(editBtn);
		}
		buttonContainer.appendChild(offlineDiv);
	  }
	}
  }


  // robust 展開/收合狀態更新函式
  function updateExpandUI() {
	// robust: 每次展開/收合時也同步 toggleButton 內容
	if (typeof toggleButton !== 'undefined' && toggleButton) {
	  toggleButton.innerText = bxToggleSymbol;
	}
	const isExpanded = getIsExpanded();
	console.log('[BX] updateExpandUI called, isExpanded:', isExpanded);
  if (isExpanded) {
	buttonContainer.style.maxWidth = '1000px';
	buttonContainer.style.height = '26px';
	buttonContainer.style.opacity = '1';
	buttonContainer.style.overflow = 'visible';
	toggleButton.style.boxShadow = '0 0 10px rgba(255, 255, 0, 0.8)';
	toggleButton.style.backgroundColor = '#fffdd0';
	// 保持正圓形
	toggleButton.style.width = '24px';
	toggleButton.style.height = '24px';
	toggleButton.style.minWidth = '24px';
	toggleButton.style.minHeight = '24px';
	toggleButton.style.maxWidth = '24px';
	toggleButton.style.maxHeight = '24px';
	toggleButton.style.aspectRatio = '1/1';
	toggleButton.style.borderRadius = '50%';
	Array.from(buttonContainer.children).forEach((child) => {
	  if (child !== toggleButton) child.style.visibility = 'visible';
	});
	console.log('[BX] 展開狀態: 所有按鈕顯示');
  } else {
	buttonContainer.style.maxWidth = '26px';
	buttonContainer.style.height = '26px';
	buttonContainer.style.opacity = '1';
	buttonContainer.style.overflow = 'hidden';
	toggleButton.style.boxShadow = 'inset 0 0 5px rgba(0, 0, 0, 0.4)';
	toggleButton.style.backgroundColor = '#f0f0f0';
	// 保持正圓形
	toggleButton.style.width = '24px';
	toggleButton.style.height = '24px';
	toggleButton.style.minWidth = '24px';
	toggleButton.style.minHeight = '24px';
	toggleButton.style.maxWidth = '24px';
	toggleButton.style.maxHeight = '24px';
	toggleButton.style.aspectRatio = '1/1';
	toggleButton.style.borderRadius = '50%';
	Array.from(buttonContainer.children).forEach((child) => {
	  if (child !== toggleButton) {
		if (child.classList && (child.classList.contains('bx-edit-btn') || child.getAttribute('role') === 'alert' || child.getAttribute('role') === 'status')) {
		  child.style.visibility = 'visible';
		} else if (child.dataset && child.dataset.showOnCollapsed === '1') {
		  child.style.visibility = 'visible';
		} else {
		  child.style.visibility = 'hidden';
		}
	  }
	});
	console.log('[BX] 收合狀態: 只顯示 C=1、鉛筆、錯誤提示');
  }
	Array.from(buttonContainer.children).forEach((child, idx) => {
	  console.log(`[BX] child[${idx}]`, child.className, child.style.visibility, child.dataset ? child.dataset.showOnCollapsed : undefined);
	});
  }

  // 初次渲染
  await renderButtons();
  updateExpandUI();

  // robust 展開/收合事件
  toggleButton.onclick = null;
  toggleButton.addEventListener('click', function(e) {
	const before = getIsExpanded();
	console.log('[BX] toggleButton clicked, isExpanded(before):', before);
	e.preventDefault();
	e.stopPropagation();
	setIsExpanded(!before);
	const after = getIsExpanded();
	console.log('[BX] isExpanded(after):', after);
	updateExpandUI();
	if (window.getSelection) {
	  window.getSelection().removeAllRanges();
	} else if (document.selection) {
	  document.selection.empty();
	}
  });

	// 將按鈕容器插入到 body
	document.body.appendChild(buttonContainer);
};

// 動態監控 DOM 變化
const observer = new MutationObserver((mutations) => {
  const significantMutation = mutations.some(
	(mutation) => mutation.type === 'childList' && mutation.addedNodes.length > 0
  );
  if (significantMutation) {
	checkAndBindEvents();
  }
});

observer.observe(document.body, { childList: true, subtree: true });
checkAndBindEvents();

// 定時自動更新與線上事件
scheduleSheetRefresh();
window.addEventListener('online', loadSheet);