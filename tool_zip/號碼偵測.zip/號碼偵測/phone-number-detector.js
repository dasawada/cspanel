// 定義台灣手機號碼的正則表達式
const myProject_phoneRegex = /(?<!\d)(09\d{2})[-\s]?\d{3}[-\s]?\d{3}(?!\d)/;

// 顯示複製成功提示
function showCopyTooltip(x, y) {
    const tooltip = document.createElement('div');
    tooltip.textContent = '複製成功';
    tooltip.style.position = 'fixed';
    tooltip.style.left = `${x}px`; // 提示框的 X 坐標
    tooltip.style.top = `${y - 30}px`; // 提示框的 Y 坐標（滑鼠上方 30px）
    tooltip.style.backgroundColor = '#333';
    tooltip.style.color = '#fff';
    tooltip.style.padding = '5px 10px';
    tooltip.style.borderRadius = '5px';
    tooltip.style.fontSize = '12px';
    tooltip.style.zIndex = '9999';
    tooltip.style.transition = 'opacity 0.3s';
    document.body.appendChild(tooltip);

    // 動畫顯示，2秒後自動隱藏
    setTimeout(() => {
        tooltip.style.opacity = '0';
        setTimeout(() => tooltip.remove(), 300);
    }, 2000);
}

// 處理雙擊事件，複製電話號碼並顯示提示
function myProject_initializeDoubleClickDetection() {
    document.body.addEventListener('dblclick', (event) => {
        const textContent = event.target.innerText || event.target.textContent;
        const match = textContent && textContent.match(myProject_phoneRegex);

        if (match) {
            const phoneNumber = match[0];
            navigator.clipboard.writeText(phoneNumber).then(() => {
                console.log(`已複製號碼: ${phoneNumber}`);
                showCopyTooltip(event.clientX, event.clientY); // 顯示提示框在滑鼠位置
            }).catch(err => {
                console.error('複製到剪貼簿失敗:', err);
            });
        }
    });
}

// 初始化雙擊事件監聽
myProject_initializeDoubleClickDetection();
