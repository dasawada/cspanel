chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'toggleVolumeControl') {
        if (message.enabled) {
            injectVolumeControl(); // 如果启用音量控制，则插入控制器
        } else {
            removeVolumeControl(); // 如果禁用音量控制，则移除控制器
        }
    }
});

function setupVolumeController(muteToggleId, volumeControllerId, volumeIconId) {
    const volumeController = document.getElementById(volumeControllerId);
    const volumeIcon = document.getElementById(volumeIconId);

    // 設置初始音量為 100%
    volumeController.value = 100;
    adjustVolume(100);

    // 更新音量條背景顏色
    function updateVolumeBackground() {
        const value = (volumeController.value - volumeController.min) / (volumeController.max - volumeController.min) * 100;
        volumeController.style.background = `linear-gradient(to right, #f2a01b ${value}%, #e0e0e0 ${value}%)`;
    }

// 調整音量的輔助函數
function adjustVolume(value) {
    const elements = document.querySelectorAll('video, audio');
    
    if (elements.length > 0) { // 確保有找到元素
        elements.forEach(element => {
            if (element) { // 確保元素存在
                element.volume = value / 100;
            }
        });
        updateVolumeBackground(); // 更新音量條背景顏色
    } else {
        console.warn('No video or audio elements found on the page.');
    }
}

    document.getElementById(muteToggleId).addEventListener('click', function () {
        if (volumeController.value > 0) {
            volumeController.value = 0;
            volumeIcon.classList.replace('fa-volume-up', 'fa-volume-mute');
            updateVolumeBackground();
        } else {
            volumeController.value = 100; // 恢復為100%
            volumeIcon.classList.replace('fa-volume-mute', 'fa-volume-up');
            updateVolumeBackground();
        }
        adjustVolume(volumeController.value);
    });

    // 添加輸入事件處理程序，以確保在滑動條滑動時更新背景顏色和音量
    volumeController.addEventListener('input', function() {
        adjustVolume(this.value);
    });

    // 初始調用以設置正確的背景
    updateVolumeBackground();
}

// 動態插入樣式並帶入 Font Awesome 字型
function injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
        @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');

        .volume-control-container {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 10px;
            border-radius: 12px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            max-width: 300px;
            margin: 0 auto;
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 9999;
        }
        #volumecontroller5 {
            flex-grow: 1;
            -webkit-appearance: none;
            background: linear-gradient(to right, #f2a01b 100%, #e0e0e0 100%);
            border-radius: 8px;
            height: 8px;
            outline: none;
            transition: background 0.3s ease-in-out;
        }
        #volumecontroller5::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #333;
            cursor: pointer;
            position: relative;
            z-index: 1;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
        #volumecontroller5::-moz-range-thumb {
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #333;
            cursor: pointer;
            position: relative;
            z-index: 1;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
    `;
    document.head.appendChild(style);
}

// 創建音量控制器的 HTML
function injectVolumeControl() {
    if (!document.querySelector('.volume-control-container')) {  // 檢查是否已經存在音量控制器
        injectStyles();  // 確保樣式注入

        const volumeControlHTML = `
        <div class="volume-control-container" style="position: fixed; top: 10px; left: 10px; z-index: 9999;">
            <button id="muteToggle5" style="background: none; border: none; cursor: pointer; flex-shrink: 0;">
                <i id="volumeIcon5" class="fas fa-volume-up"></i>
            </button>
            <input type="range" id="volumecontroller5" min="0" max="100" value="100">
        </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = volumeControlHTML;
        document.body.appendChild(container);
        setupVolumeController('muteToggle5', 'volumecontroller5', 'volumeIcon5');
    }
}

// 移除音量控制器
function removeVolumeControl() {
    const volumeControl = document.querySelector('.volume-control-container');
    if (volumeControl) {
        volumeControl.remove();
    }
}

// 重置音量的輔助函數
function resetVolume() {
    const elements = document.querySelectorAll('video, audio');
    elements.forEach(element => {
        element.volume = 1.0; // 將音量重置為 100%
    });
}

// 修改後的移除音量控制器函數
function removeVolumeControl() {
    resetVolume(); // 重置音量
    const volumeControl = document.querySelector('.volume-control-container');
    if (volumeControl) {
        volumeControl.remove();
    }
}
