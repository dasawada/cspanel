document.addEventListener('DOMContentLoaded', function() {
    // 點名功能，這部分的邏輯保持不變
	function showRows() {
		var rows = document.querySelectorAll('.MuiTableRow-root');
		rows.forEach(function(row) {
			// 如果行具有表頭類名，則保持顯示
			if (row.classList.contains('MuiTableRow-head')) {
				row.style.display = ''; // 保持顯示
				return;
			}

			var cells = row.querySelectorAll('.MuiTableCell-root');
			var shouldShowRow = false;

			cells.forEach(function(cell) {
				var box1 = cell.querySelector('.MuiBox-root.css-1v9l4og');
				var box2 = cell.querySelector('.MuiBox-root.css-1tqg586');

				if (box1 && box2 && !box2.querySelector('.MuiBox-root')) {
					shouldShowRow = true;
				}
			});

			row.style.display = shouldShowRow ? 'table-row' : 'none';
		});
	}
	
    // 解除點名功能
    function showAllRows() {
        var rows = document.querySelectorAll('.MuiTableRow-root');
        rows.forEach(function(row) {
            row.style.display = ''; // 恢復到默認顯示狀態
        });
    }

    // 隱藏包含 "解題教室" 的行
	function hideTableRowIfContainsText() {
		const tableRows = document.querySelectorAll('tr.MuiTableRow-root');
		tableRows.forEach(row => {
			// 如果行具有表頭類名，則跳過
			if (row.classList.contains('MuiTableRow-head')) {
				row.style.display = ''; // 保持顯示
				return;
			}

			if (row.textContent.includes('解題教室')) {
				row.style.display = 'none';
				console.log('Row containing "解題教室" has been hidden.');
			}
		});
	}

    // 顯示包含 "解題教室" 的行
	function showTableRowIfHidden() {
		const tableRows = document.querySelectorAll('tr.MuiTableRow-root');
		tableRows.forEach(row => {
			// 如果行具有表頭類名，則跳過
			if (row.classList.contains('MuiTableRow-head')) {
				row.style.display = ''; // 保持顯示
				return;
			}

			if (row.textContent.includes('解題教室') && row.style.display === 'none') {
				row.style.display = '';
				console.log('Row containing "解題教室" has been restored.');
			}
		});
	}

    let classroomHidden = false;

    // 綁定按鈕點擊事件
    document.getElementById('take-attendance').addEventListener('click', function() {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: showRows // 確保這裡的語法正確
            });
        });
    });

    document.getElementById('cancel-attendance').addEventListener('click', function() {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: showAllRows // 確保這裡的語法正確
            });
        });
    });

    document.getElementById('toggle-classroom').addEventListener('click', function() {
        classroomHidden = !classroomHidden; // 切換狀態
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: classroomHidden ? hideTableRowIfContainsText : showTableRowIfHidden // 切換隱藏/顯示
            });
        });
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const toggleSwitch = document.getElementById('toggleVolumeControl');

    // 查询当前活动标签页
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTabId = tabs[0].id;

        // 从 local 存储中获取当前活动标签页的开关状态并更新 UI
        chrome.storage.local.get(`volumeControlEnabled_${activeTabId}`, (data) => {
            const isEnabled = data[`volumeControlEnabled_${activeTabId}`] || false;
            toggleSwitch.checked = isEnabled;
        });

        // 监听开关状态变化
        toggleSwitch.addEventListener('change', () => {
            const enabled = toggleSwitch.checked;

            // 设置当前活动标签页的状态到 local 存储
            chrome.storage.local.set({ [`volumeControlEnabled_${activeTabId}`]: enabled }, () => {
                // 确保只在需要时注入脚本
                if (enabled) {
                    chrome.scripting.executeScript(
                        {
                            target: { tabId: activeTabId },
                            files: ['volume-content.js'],
                        },
                        () => {
                            // 在脚本注入成功后发送消息来控制音量控制器
                            chrome.tabs.sendMessage(activeTabId, { action: 'toggleVolumeControl', enabled: enabled });
                        }
                    );
                } else {
                    // 禁用音量控制器
                    chrome.tabs.sendMessage(activeTabId, { action: 'toggleVolumeControl', enabled: false });
                }
            });
        });
    });
});
document.addEventListener("DOMContentLoaded", () => {
    const inputZone = document.getElementById("inputZone");

    // 處理粘貼事件
    inputZone.addEventListener("paste", (event) => {
        event.preventDefault();
        const pasteData = (event.clipboardData || window.clipboardData).getData("text").trim();
        if (pasteData) {
            openNewWindow(pasteData);
            inputZone.textContent = "MMS ID";
        }
    });

    // 按下 Enter 提交文字
    inputZone.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            const content = inputZone.textContent.trim();
            if (content) {
                openNewWindow(content);
                inputZone.textContent = "MMS ID";
            }
        }
    });

    // 清除預設提示文字
    inputZone.addEventListener("focus", () => {
        if (inputZone.textContent.trim() === "MMS ID") {
            inputZone.textContent = "";
        }
    });

    // 如果輸入框失去焦點且未填寫，恢復提示文字
    inputZone.addEventListener("blur", () => {
        if (!inputZone.textContent.trim()) {
            inputZone.textContent = "MMS ID";
        }
    });

    // 拖放事件
    inputZone.addEventListener("dragover", (event) => {
        event.preventDefault();
        inputZone.style.backgroundColor = "#f1f1f1";
    });

    inputZone.addEventListener("dragleave", () => {
        inputZone.style.backgroundColor = "#fff";
    });

    inputZone.addEventListener("drop", (event) => {
        event.preventDefault();
        inputZone.style.backgroundColor = "#fff";
        const text = event.dataTransfer.getData("text").trim();
        if (text) {
            openNewWindow(text);
            inputZone.textContent = "MMS ID";
        }
    });

    // 打開新視窗
    function openNewWindow(content) {
        const targetUrl = `https://oneclub.backstage.oneclass.com.tw/customer/customerlist/${content}`;
        window.open(targetUrl, "_blank", "width=800,height=600");
    }
});
