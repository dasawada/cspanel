document.addEventListener('DOMContentLoaded', function() {
    const nameItems = document.querySelectorAll('.name-item');
    
    nameItems.forEach(item => {
        item.addEventListener('click', function() {
            const text = this.textContent;
            navigator.clipboard.writeText(text).then(() => {
                this.classList.add('copied');
                setTimeout(() => {
                    this.classList.remove('copied');
                }, 1000);
            });
        });
    });
});