function sendMessage(message) {
    return new Promise((resolve, reject) => {
        try {
            chrome.runtime.sendMessage(message, response => {
                if (chrome.runtime.lastError) {
                    // Suppress the error and resolve with null
                    resolve(null);
                } else {
                    resolve(response);
                }
            });
        } catch (error) {
            resolve(null);
        }
    });
}

// Add this to window for global access
window.sendMessage = sendMessage;
