document.addEventListener('DOMContentLoaded', function() {
    // Firebase configuration
    const firebaseConfig = {
        apiKey: "AIzaSyAhgA5nFE3bLTVyudYjKctSpnTCIgORg8M",
        authDomain: "cstoolsapi.firebaseapp.com",
        projectId: "cstoolsapi",
        storageBucket: "cstoolsapi.firebasestorage.app",
        messagingSenderId: "632885029336",
        appId: "1:632885029336:web:f491b9cc28fe3f2504aaad"
    };

    // Initialize Firebase
    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
    }
    const auth = firebase.auth();

    // DOM elements
    const loginContainer = document.getElementById('login-container');
    const appContent = document.getElementById('app-content');
    const loginForm = document.getElementById('login-form');
    const emailInput = document.getElementById('email-input');
    const passwordInput = document.getElementById('password-input');
    const loginError = document.getElementById('login-error');
    // 移除登出按鈕取得
    // const logoutButton = document.getElementById('logout-button');

    // 預設隱藏操作面板與登入表單，等驗證完再顯示
    if (appContent) {
        appContent.classList.add('hidden');
    }
    if (loginContainer) {
        loginContainer.classList.add('hidden');
    }

    // 關鍵改變：根據本地儲存的登入狀態立即顯示對應界面
    chrome.storage.local.get(['lastLoginState', 'lastLoginTime'], function(result) {
        const lastLoginState = result.lastLoginState;
        const lastLoginTime = result.lastLoginTime;
        const now = Date.now();
        
        // 如果上次登入時間在24小時內，預設顯示應用內容
        const shouldShowApp = lastLoginState === 'logged-in' && 
                             lastLoginTime && 
                             (now - lastLoginTime) < 24 * 60 * 60 * 1000;
        
        if (shouldShowApp) {
            // 立即顯示應用內容和彩色背景
            if (loginContainer) loginContainer.classList.add('hidden');
            if (appContent) appContent.classList.remove('hidden');
            document.body.classList.add('colorful'); // 設置彩色背景
            console.log("基於上次登入狀態，直接顯示應用內容");
        } else {
            // 立即顯示登入頁面，確保灰階背景
            if (appContent) appContent.classList.add('hidden');
            if (loginContainer) loginContainer.classList.remove('hidden');
            document.body.classList.remove('colorful'); // 確保灰階背景
            console.log("無有效登入狀態，顯示登入頁面");
        }
        
        // 初始化應用功能（不論登入狀態）
        initializeAppLogic();
        
        // 在背景靜默驗證真實登入狀態
        firebase.auth().onAuthStateChanged(function (user) {
            if (user) {
                // 自動續期本地登入狀態
                chrome.storage.local.set({
                    'lastLoginState': 'logged-in',
                    'lastLoginTime': Date.now()
                });
                // 檢查當前是否顯示登入頁面，如果是則執行轉場動畫
                if (!loginContainer.classList.contains('hidden')) {
                    console.log("執行登入成功轉場動畫");
                    handleLoginSuccess(); // 這裡會使用轉場動畫
                } else {
                    // 如果已經在主頁面，直接設置彩色（無動畫）
                    document.body.classList.add('colorful');
                    console.log("用戶已在主頁面，直接設置彩色背景");
                }
                
                console.log("背景驗證：用戶已登入", user.email);
                
                // 靜默檢查 token 有效性
                user.getIdToken(true).then(() => {
                    console.log("Token 有效，維持登入狀態");
                }).catch((error) => {
                    console.error("Token 無效，需要重新登入:", error);
                    handleLogout();
                });
            } else {
                // 直接移除彩色（無動畫）
                document.body.classList.remove('colorful', 'login-transition');
                
                // 用戶未登入，更新本地狀態
                chrome.storage.local.set({
                    'lastLoginState': 'logged-out',
                    'lastLoginTime': null
                });
                
                // 只有當前顯示應用內容時才需要切換
                if (!appContent.classList.contains('hidden')) {
                    handleLogout();
                }
                
                console.log("背景驗證：用戶未登入");
            }
        });
    });

    // 統一的登出處理函數
    function handleLogout() {
        console.log("開始登出轉場動畫（驗證失效）");
        
        // 立即變回灰階
        document.body.classList.remove('colorful');
        
        // 開始淡出主應用內容
        appContent.classList.add('fade-out');
        
        // 等待淡出完成 (0.8秒)
        setTimeout(() => {
            // 隱藏主應用並顯示登入頁面
            appContent.classList.add('hidden');
            appContent.classList.remove('fade-out'); // 清除淡出樣式
            
            loginContainer.classList.remove('hidden');
            loginContainer.classList.add('fade-in');
            
            // 清除登入頁面的淡入樣式（為下次登入做準備）
            setTimeout(() => {
                loginContainer.classList.remove('fade-in');
            }, 800);
            
            console.log("登出轉場動畫完成");
        }, 800); // 與 CSS fade-out 動畫時間一致
        
        // 更新本地儲存
        chrome.storage.local.set({
            'lastLoginState': 'logged-out',
            'lastLoginTime': null
        });
    }

    // Login form event
    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            e.preventDefault();
            
            const email = emailInput.value.trim();
            const password = passwordInput.value.trim();
            
            if (!email || !password) {
                showLoginError('請輸入電子郵件和密碼');
                return;
            }
            
            // 顯示載入狀態
            const loginButton = document.getElementById('login-button');
            const originalText = loginButton.textContent;
            loginButton.textContent = '登入中...';
            loginButton.disabled = true;
            hideLoginError();
            
            firebase.auth().signInWithEmailAndPassword(email, password)
                .then((userCredential) => {
                    console.log("登入成功:", userCredential.user.email);
                    // 清除表單
                    emailInput.value = '';
                    passwordInput.value = '';
                    // 不要在這裡直接調用 handleLoginSuccess()
                    // 讓 onAuthStateChanged 來處理轉場動畫
                    
                    // 更新本地狀態
                    chrome.storage.local.set({
                        'lastLoginState': 'logged-in',
                        'lastLoginTime': Date.now()
                    });
                })
                .catch((error) => {
                    console.error("登入失敗:", error.code, error.message);
                    let errorMessage = '登入失敗';
                    
                    switch (error.code) {
                        case 'auth/user-not-found':
                            errorMessage = '找不到此帳戶';
                            break;
                        case 'auth/wrong-password':
                            errorMessage = '密碼錯誤';
                            break;
                        case 'auth/invalid-email':
                            errorMessage = '電子郵件格式錯誤';
                            break;
                        case 'auth/user-disabled':
                            errorMessage = '此帳戶已被停用';
                            break;
                        case 'auth/too-many-requests':
                            errorMessage = '嘗試次數過多，請稍後再試';
                            break;
                        default:
                            errorMessage = error.message;
                    }
                    
                    showLoginError(errorMessage);
                })
                .finally(() => {
                    // 恢復按鈕狀態
                    loginButton.textContent = originalText;
                    loginButton.disabled = false;
                });
        });
    }

    // 移除登出按鈕事件註冊
    // if (logoutButton) {
    //     logoutButton.addEventListener('click', function () {
    //         firebase.auth().signOut()
    //             .then(() => {
    //                 console.log("登出成功");
    //                 // 登出後顯示登入頁面
    //                 handleLogout();
    //             })
    //             .catch((error) => {
    //                 console.error("登出失敗:", error);
    //             });
    //     });
    // }
    
    // Helper functions for login error handling
    function showLoginError(message) {
        loginError.textContent = message;
        loginError.style.display = 'block';
    }
    
    function hideLoginError() {
        loginError.style.display = 'none';
    }

    // Helper function to call the Netlify backend API
    async function callNetlifyAPI(action, dataPayload = {}) {
        const user = firebase.auth().currentUser;
        if (!user) {
            console.error("User not authenticated for API call");
            throw new Error("User not authenticated");
        }

        try {
            const firebaseToken = await user.getIdToken();
            const response = await fetch('https://stirring-pothos-28253d.netlify.app/.netlify/functions/extensionAPI', { // Replace with your actual Netlify site name
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    token: firebaseToken,
                    action: action,
                    data: dataPayload
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ error: `HTTP error! status: ${response.status}` }));
                console.error(`API call failed for action ${action}:`, errorData);
                throw new Error(errorData.error || `API request failed for ${action}`);
            }
            return response.json();
        } catch (error) {
            console.error(`Error in callNetlifyAPI for action ${action}:`, error);
            throw error; // Re-throw to be caught by the caller
        }
    }

    function initializeAppLogic() {
        console.log("初始化應用程式邏輯...");
        
        // 點名功能
        function showRows() {
            var rows = document.querySelectorAll('.MuiTableRow-root');
            let nameList = [];

            rows.forEach(function(row) {
                if (row.classList.contains('MuiTableRow-head')) {
                    row.style.display = '';
                    return;
                }
                var cells = row.querySelectorAll('.MuiTableCell-root');
                var shouldShowRow = false;
                var specialType = '';
                
                const rowText = row.textContent.trim();
                if (rowText.includes('解題')) {
                    specialType = '解題';
                } else if (rowText.includes('試聽')) {
                    specialType = '試聽';
                } else if (rowText.includes('測試')) {
                    specialType = '測試';
                } else if (rowText.includes('檢核')) {
                    specialType = '檢核';
                } else if (rowText.includes('待命')) {
                    specialType = '待命';
                }
                
                cells.forEach(function(cell) {
                    const box1 = cell.querySelector('.MuiBox-root.css-1v9l4og');
                    const box2 = cell.querySelector('.MuiBox-root.css-1tqg586');
                    
                    if (box1 && box2 && !box2.querySelector('.MuiBox-root')) {
                        shouldShowRow = true;
                        const teacherName = box2.textContent.trim();
                        
                        if (specialType) {
                            nameList.push(`${teacherName}（${specialType}）`);
                        } else {
                            nameList.push(teacherName);
                        }
                    }
                });
                row.style.display = shouldShowRow ? 'table-row' : 'none';
            });

            if (nameList.length > 0) {
                const currentDateTime = new Date().toLocaleString('zh-TW', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: false
                }).replace(/\//g, '-');

                const htmlContent = `
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <meta charset="UTF-8">
                        <title>點名名單 ${currentDateTime}</title>
                        <style>
                            body { font-family: Arial, sans-serif; padding: 20px; }
                            h2 { color: #333; font-size: small; }
                            .name-list { margin-bottom: 10px; }
                            .name-item { 
                                line-height: 1.6;
                                background: #f5f5f5;
                                padding: 8px 15px;
                                border-radius: 5px;
                                cursor: pointer;
                                transition: background-color 0.3s ease;
                                margin-bottom: 5px;
                                font-size: small;
                            }
                            .name-item:hover {
                                background: #e0e0e0;
                            }
                            .count { color: #666; margin-top: 10px; }
                        </style>
                    </head>
                    <body>
                        <h2>點名名單 ${currentDateTime}</h2>
                        <div class="name-list">
                            ${nameList.map(name => `<div class="name-item">${name}</div>`).join('')}
                        </div>
                        <div class="count">共 ${nameList.length} 人</div>
                    </body>
                    </html>
                `;

                const newWindow = window.open('', '_blank', 'width=400,height=600');
                if (newWindow) {
                    newWindow.document.write(htmlContent);
                    newWindow.document.close();
                }
            }
        }
        
        function showAllRows() {
            var rows = document.querySelectorAll('.MuiTableRow-root');
            rows.forEach(function(row) {
                row.style.display = '';
            });
        }
        
        function hideTableRowIfContainsText() {
            const tableRows = document.querySelectorAll('tr.MuiTableRow-root');
            tableRows.forEach(row => {
                if (row.classList.contains('MuiTableRow-head')) {
                    row.style.display = '';
                    return;
                }
                if (row.textContent.includes('解題教室')) {
                    row.style.display = 'none';
                }
            });
        }
        
        function showTableRowIfHidden() {
            const tableRows = document.querySelectorAll('tr.MuiTableRow-root');
            tableRows.forEach(row => {
                if (row.classList.contains('MuiTableRow-head')) {
                    row.style.display = '';
                    return;
                }
                if (row.textContent.includes('解題教室') && row.style.display === 'none') {
                    row.style.display = '';
                }
            });
        }
        
        let classroomHidden = false;
        
        // 點名按鈕事件
        const takeAttendanceBtn = document.getElementById('take-attendance');
        if (takeAttendanceBtn) {
            takeAttendanceBtn.addEventListener('click', function() {
                chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
                    if (tabs[0]) {
                        chrome.scripting.executeScript({
                            target: { tabId: tabs[0].id },
                            func: showRows
                        });
                    }
                });
            });
        }
        
        // 還原按鈕事件
        const cancelAttendanceBtn = document.getElementById('cancel-attendance');
        if (cancelAttendanceBtn) {
            cancelAttendanceBtn.addEventListener('click', function() {
                chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
                    if (tabs[0]) {
                        chrome.scripting.executeScript({
                            target: { tabId: tabs[0].id },
                            func: showAllRows
                        });
                    }
                });
            });
        }
        
        // 教室切換按鈕事件
        const toggleClassroomBtn = document.getElementById('toggle-classroom');
        if (toggleClassroomBtn) {
            toggleClassroomBtn.addEventListener('click', function() {
                classroomHidden = !classroomHidden;
                chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
                    if (tabs[0]) {
                        chrome.scripting.executeScript({
                            target: { tabId: tabs[0].id },
                            func: classroomHidden ? hideTableRowIfContainsText : showTableRowIfHidden
                        });
                    }
                });
            });
        }
        
        // 音量控制功能
        const toggleSwitch = document.getElementById('toggleVolumeControl');
        if (toggleSwitch) {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    const activeTabId = tabs[0].id;
                    chrome.storage.local.get(`volumeControlEnabled_${activeTabId}`, (data) => {
                        const isEnabled = data[`volumeControlEnabled_${activeTabId}`] || false;
                        toggleSwitch.checked = isEnabled;
                    });
                    
                    toggleSwitch.addEventListener('change', () => {
                        const enabled = toggleSwitch.checked;
                        chrome.storage.local.set({ [`volumeControlEnabled_${activeTabId}`]: enabled }, () => {
                            if (enabled) {
                                chrome.scripting.executeScript({
                                    target: { tabId: activeTabId },
                                    files: ['volume-content.js'],
                                }, () => {
                                    chrome.tabs.sendMessage(activeTabId, { action: 'toggleVolumeControl', enabled: enabled });
                                });
                            } else {
                                chrome.tabs.sendMessage(activeTabId, { action: 'toggleVolumeControl', enabled: false });
                            }
                        });
                    });
                }
            });
        }
        
        // 課程查詢功能
        const inputZone = document.getElementById("inputZone");
        const classInfoResult = document.getElementById("classInfoResult");
        const clearBtn = document.getElementById("clearInputZone"); 

        let animationStopper = null; // 控制動畫停止

        // 搜尋進行動畫
        function applySpeedCurveAnimation(profile, duration = 800) {
            let running = true;
            let frameId = null; 

            function computeProgress(p) {
                const d = [0];
                for (let i = 1; i < p.length; i++) {
                    d[i] = d[i - 1] + ((p[i - 1].v + p[i].v) / 2) * (p[i].t - p[i - 1].t);
                }
                return d.map(x => x / d[p.length - 1]);
            }

            function drawFrame(now) {
                if (!running) { 
                    return;
                }
                const tnorm = (now % (duration * 2)) / duration, tp = tnorm > 1 ? 2 - tnorm : tnorm;
                let lo = 0, hi = profile.length - 1;
                while (hi - lo > 1) {
                    const m = (lo + hi) >> 1;
                    profile[m].t < tp ? lo = m : hi = m;
                }
                const pr = computeProgress(profile), pct = Math.round((pr[lo] + (pr[hi] - pr[lo]) * ((tp - profile[lo].t) / (profile[hi].t - profile[lo].t || 1))) * 100);
                inputZone.style.background = `linear-gradient(292deg,rgb(179, 101, 131) 0%,rgb(114, 167, 187) ${pct}%,rgb(177, 143, 98) 100%)`;
                
                frameId = requestAnimationFrame(drawFrame); 
            }

            frameId = requestAnimationFrame(drawFrame); 

            return () => {
                running = false;
                if (frameId) {
                    cancelAnimationFrame(frameId);
                    frameId = null;
                }
                inputZone.style.background = ""; 
            };
        }

        if (inputZone && classInfoResult && clearBtn) {
            // 顯示/隱藏 X 按鈕
            function updateClearBtn() {
                if (inputZone.value.trim() !== "") { // Changed from textContent
                    clearBtn.style.display = "block";
                } else {
                    clearBtn.style.display = "none";
                }
            }

            // 處理貼上事件
            inputZone.addEventListener("paste", (event) => {
                event.preventDefault();
                const pasteData = (event.clipboardData || window.clipboardData).getData("text").trim();
                if (pasteData) {
                    inputZone.value = pasteData; // Changed from textContent
                    updateClearBtn(); 
                    startSearch(pasteData);
                }
            });

            // 處理Enter鍵
            inputZone.addEventListener("keydown", (event) => {
                if (event.key === "Enter") {
                    event.preventDefault();
                    const content = inputZone.value.trim(); // Changed from textContent
                    if (content) { // Simplified condition, placeholder handles "教室ID／OCID"
                        startSearch(content);
                    }
                }
            });

            // 處理輸入事件，動態顯示 X
            inputZone.addEventListener("input", updateClearBtn);

            // 處理焦點事件
            inputZone.addEventListener("focus", () => {
                // Placeholder text is handled by the input element itself
                updateClearBtn();
            });

            inputZone.addEventListener("blur", () => {
                // Placeholder text is handled by the input element itself
                // Call updateClearBtn in case focus is lost with content still in (e.g. via tab)
                updateClearBtn(); 
            });

            // 清除按鈕事件
            clearBtn.addEventListener("click", () => {
                inputZone.value = ""; // Changed from textContent
                if (animationStopper) { 
                    animationStopper();
                    animationStopper = null; 
                }
                updateClearBtn();
                inputZone.focus(); 
            });

            // 初始狀態設定 - placeholder attribute handles initial text
            updateClearBtn(); // Call once to set initial state of clear button
        }

        // 封裝搜尋流程
        function startSearch(content) {
            if (animationStopper) { 
                animationStopper(); 
            }
            animationStopper = applySpeedCurveAnimation(
                [{"t":0,"v":0},{"t":0.1171875,"v":0.0365625},{"t":0.36875,"v":0.1415625},{"t":0.4328125,"v":0.8465625},{"t":0.49375,"v":0.9965625},{"t":0.5515625,"v":0.8765625},{"t":0.6203125,"v":0.1315625},{"t":0.809375,"v":0.0515625},{"t":1,"v":0}],
                800
            );
            checkAndFetchInfo(content); // Ensure this function is defined elsewhere or included
        }

        // 檢查並獲取課程資訊
        async function checkAndFetchInfo(content) {
            classInfoResult.style.display = "block";
            classInfoResult.innerHTML = "<p>處理中...</p>";

            try {
                const response = await callNetlifyAPI('checkAndProcessCourseInfo', { content });

                if (response.success) {
                    // Server now provides 'html' and optional 'redirectUrl' in response.data
                    if (response.data && typeof response.data.html === 'string') {
                        classInfoResult.innerHTML = response.data.html;
                    } else {
                        // Fallback if html is missing or not a string, though server should always provide it correctly
                        classInfoResult.innerHTML = "<p style='color:orange;'>收到未完整的成功回應。</p>";
                    }

                    if (response.data && response.data.redirectUrl) {
                        chrome.tabs.create({ url: response.data.redirectUrl });
                    }
                } else {
                    // response.success is false
                    // Server might provide specific HTML for the error in response.data.html
                    if (response.data && typeof response.data.html === 'string') {
                        classInfoResult.innerHTML = response.data.html;
                    } 
                    // Or use the general error message from response.error
                    else if (response.error) {
                        classInfoResult.innerHTML = `<p style="color:red;">查詢失敗：${response.error}</p>`;
                    } 
                    // Fallback for unexpected error structure
                    else {
                        classInfoResult.innerHTML = `<p style="color:red;">查詢失敗：未知錯誤</p>`;
                    }
                }
            } catch (error) {
                // This catch handles errors from callNetlifyAPI itself (e.g., network issues)
                console.error("checkAndFetchInfo Client Error:", error);
                classInfoResult.innerHTML = `<p style="color:red;">查詢時發生錯誤：${error.message}</p>`;
            } finally {
                // 動畫在結果出現時結束
                if (animationStopper) {
                    animationStopper(); 
                    animationStopper = null; 
                }
            }
        }
    }

    // 修改 onAuthStateChanged 的邏輯
    firebase.auth().onAuthStateChanged(function (user) {
        if (user) {
            // 自動續期本地登入狀態
            chrome.storage.local.set({
                'lastLoginState': 'logged-in',
                'lastLoginTime': Date.now()
            });
            // 檢查當前是否顯示登入頁面，如果是則執行轉場動畫
            if (!loginContainer.classList.contains('hidden')) {
                console.log("執行登入成功轉場動畫");
                handleLoginSuccess(); // 這裡會使用轉場動畫
            } else {
                // 如果已經在主頁面，直接設置彩色（無動畫）
                document.body.classList.add('colorful');
                console.log("用戶已在主頁面，直接設置彩色背景");
            }
            
            console.log("背景驗證：用戶已登入", user.email);
            
            // 靜默檢查 token 有效性
            user.getIdToken(true).then(() => {
                console.log("Token 有效，維持登入狀態");
            }).catch((error) => {
                console.error("Token 無效，需要重新登入:", error);
                handleLogout();
            });
        } else {
            // 直接移除彩色（無動畫）
            document.body.classList.remove('colorful', 'login-transition');
            
            // 用戶未登入，更新本地狀態
            chrome.storage.local.set({
                'lastLoginState': 'logged-out',
                'lastLoginTime': null
            });
            
            // 只有當前顯示應用內容時才需要切換
            if (!appContent.classList.contains('hidden')) {
                handleLogout();
            }
            
            console.log("背景驗證：用戶未登入");
        }
    });

    // 修改 handleLoginSuccess 函數
    function handleLoginSuccess() {
        const loginContainer = document.getElementById('login-container');
        const appContent = document.getElementById('app-content');
        
        console.log("開始登入成功轉場動畫");
        
        if (!appContent.classList.contains('hidden')) {
            appContent.classList.add('hidden');
        }
        
        // 使用特殊的轉場類別（有動畫）- 背景轉換將會在 3 秒內完成
        document.body.classList.add('login-transition');
        loginContainer.classList.add('fade-out'); // 淡出動畫持續 5s
        
        // 讓淡入和淡出同時開始，產生完美交疊
        setTimeout(() => {
            loginContainer.classList.add('hidden');
            loginContainer.classList.remove('fade-out');
            
            appContent.classList.remove('hidden');
            appContent.classList.add('fade-in'); // 淡入動畫持續 1s
            
            document.body.classList.add('colorful');
            
            // 在淡入動畫完成後移除相關類別
            setTimeout(() => {
                appContent.classList.remove('fade-in');
                console.log("淡入淡出動畫完成");
            }, 1000); // 1秒後移除淡入類別
            
            // 單獨控制背景轉換類別的移除時間
            setTimeout(() => {
                document.body.classList.remove('login-transition');
                console.log("背景轉換動畫完成");
            }, 500); // 背景轉換動畫持續 0.5 秒
                
        }, 0); // 立即開始淡入，與淡出完全同時
    }
});
