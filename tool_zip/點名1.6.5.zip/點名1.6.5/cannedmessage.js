document.addEventListener("DOMContentLoaded", function() {
    // 綁定按鈕的點擊事件
    document.getElementById('copyNotInClass').addEventListener('click', function() {
        copyToClipboard('老師您好，現在的課程您還沒有進教室喔，請問有發生什麼狀況需要協助嗎？', this);
    });
    document.getElementById('copyMakeUpHours').addEventListener('click', function() {
        copyToClipboard('查看老師已進入教室了，再麻煩老師補足上課時數哦，謝謝老師！', this);
    });
});

function copyToClipboard(text, buttonElement) {
    var textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);

    // 保存原始按钮文本
    var originalText = buttonElement.textContent;
    
    // 将按钮内文替换为 "－－"
    buttonElement.textContent = '－－';
    
    // 一秒后恢复原始文本
    setTimeout(function() {
        buttonElement.textContent = originalText;
    }, 1000); // 1000毫秒 = 1秒
}