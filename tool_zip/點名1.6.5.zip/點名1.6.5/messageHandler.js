class MessageHandler {
    static instance;
    static queue = [];
    static port = null;
    static isProcessing = false;

    static getInstance() {
        if (!this.instance) {
            this.instance = new MessageHandler();
            this.connect();
        }
        return this.instance;
    }

    static async connect() {
        if (this.port) return;
        
        try {
            this.port = chrome.runtime.connect({name: 'popup'});
            
            this.port.onDisconnect.addListener(() => {
                this.port = null;
                if (this.queue.length > 0) {
                    setTimeout(() => this.connect(), 100);
                }
            });

            this.processQueue();
        } catch (error) {
            console.log('Connection failed:', error);
            this.port = null;
        }
    }

    static async sendMessage(message) {
        return new Promise((resolve) => {
            this.queue.push({message, resolve});
            if (!this.isProcessing) {
                this.processQueue();
            }
        });
    }

    static async processQueue() {
        if (this.isProcessing || this.queue.length === 0) return;
        
        this.isProcessing = true;
        while (this.queue.length > 0) {
            if (!this.port) {
                await this.connect();
            }

            const {message, resolve} = this.queue[0];
            try {
                const response = await this.sendMessageToPort(message);
                resolve(response);
            } catch (error) {
                console.log('Error processing message:', error);
                resolve(null);
            }
            this.queue.shift();
        }
        this.isProcessing = false;
    }

    static sendMessageToPort(message) {
        return new Promise((resolve) => {
            try {
                if (!this.port) {
                    resolve(null);
                    return;
                }

                const handleResponse = (response) => {
                    this.port.onMessage.removeListener(handleResponse);
                    resolve(response);
                };

                this.port.onMessage.addListener(handleResponse);
                this.port.postMessage(message);

                // 設置超時
                setTimeout(() => {
                    this.port.onMessage.removeListener(handleResponse);
                    resolve(null);
                }, 5000);
            } catch (error) {
                resolve(null);
            }
        });
    }

    // 用於 window.open 操作的特殊處理
    static async handleWindowOpen(url, options) {
        const win = window.open(url, '_blank', options);
        if (win) {
            // 確保消息隊列在新窗口打開後被處理
            await this.processQueue();
        }
        return win;
    }
}

// 替換原有的 chrome.runtime.sendMessage
window.chrome.runtime.sendMessage = MessageHandler.sendMessage.bind(MessageHandler);
// 替換原有的 window.open
const originalWindowOpen = window.open;
window.open = function(url, target, features) {
    return MessageHandler.handleWindowOpen(url, features);
};
