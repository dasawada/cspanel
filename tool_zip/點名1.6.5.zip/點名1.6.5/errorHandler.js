class ErrorHandler {
    static handleRuntimeError(error) {
        if (chrome.runtime.lastError) {
            console.log('Handled runtime error:', chrome.runtime.lastError.message);
            return null;
        }
        return error;
    }

    static async retryOperation(operation, maxRetries = 3, delay = 1000) {
        for (let i = 0; i < maxRetries; i++) {
            try {
                return await operation();
            } catch (error) {
                if (i === maxRetries - 1) throw error;
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }
}

window.ErrorHandler = ErrorHandler;
