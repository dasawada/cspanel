chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // 建議添加日誌來調試消息接收
    console.log("Content script received message:", message);
    if (message.action === 'toggleVolumeControl') {
        if (message.enabled) {
            injectVolumeControl(); // 如果启用音量控制，则插入控制器
        } else {
            removeVolumeControl(); // 如果禁用音量控制，则移除控制器
        }
        // 建議發送回應，表明消息已處理
        sendResponse({status: "processed", action: message.action, enabled: message.enabled});
        return true; // 為了異步 sendResponse
    }
});

function setupVolumeController(muteToggleId, volumeControllerId, volumeIconId) {
    const volumeController = document.getElementById(volumeControllerId);
    const volumeIcon = document.getElementById(volumeIconId);

    // 此函數現在是 setupVolumeController 的局部函數，可以正確訪問 volumeController
    function updateVolumeBackgroundScoped() {
        if (volumeController) { // 確保 volumeController 存在
            const value = (parseFloat(volumeController.value) - parseFloat(volumeController.min)) / (parseFloat(volumeController.max) - parseFloat(volumeController.min)) * 100;
            volumeController.style.background = `linear-gradient(to right, #f2a01b ${value}%, #e0e0e0 ${value}%)`;
        }
    }

    if (!volumeController || !volumeIcon) {
        console.error("Volume controller or icon element not found for setup:", volumeControllerId, volumeIconId);
        return;
    }

    // 設置初始音量為 100%
    volumeController.value = 100;
    adjustVolume(100); // 全域 adjustVolume 僅調整媒體音量
    updateVolumeBackgroundScoped(); // 使用局部函數更新此特定控制器的 UI

    document.getElementById(muteToggleId).addEventListener('click', function () {
        if (parseFloat(volumeController.value) > 0) {
            volumeController.value = 0;
            volumeIcon.classList.replace('fa-volume-up', 'fa-volume-mute');
        } else {
            volumeController.value = 100; // 恢復為100%
            volumeIcon.classList.replace('fa-volume-mute', 'fa-volume-up');
        }
        adjustVolume(volumeController.value); // 全域 adjustVolume
        updateVolumeBackgroundScoped();       // 更新此特定控制器的 UI
    });

    // 添加輸入事件處理程序，以確保在滑動條滑動時更新背景顏色和音量
    volumeController.addEventListener('input', function() {
        adjustVolume(this.value);         // 全域 adjustVolume
        updateVolumeBackgroundScoped();   // 更新此特定控制器的 UI
    });

    // 初始調用以設置正確的背景
    updateVolumeBackgroundScoped();
}

// 動態插入樣式並帶入 Font Awesome 字型
function injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
        @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');

        .volume-control-container {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 10px;
            border-radius: 12px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            max-width: 300px;
            margin: 0 auto;
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 9999;
            border: 2px solid #f2a01b;
        }
        #volumecontroller5 {
            flex-grow: 1;
            -webkit-appearance: none;
            background: linear-gradient(to right, #f2a01b 100%, #e0e0e0 100%);
            border-radius: 8px;
            height: 8px;
            outline: none;
            transition: background 0.3s ease-in-out;
        }
        #volumecontroller5::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #333;
            cursor: pointer;
            position: relative;
            z-index: 1;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
        #volumecontroller5::-moz-range-thumb {
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #333;
            cursor: pointer;
            position: relative;
            z-index: 1;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
    `;
    document.head.appendChild(style);
}

// 創建音量控制器的 HTML
function injectVolumeControl() {
    if (!document.querySelector('.volume-control-container')) {  // 檢查是否已經存在音量控制器
        injectStyles();  // 確保樣式注入

        const volumeControlHTML = `
        <div class="volume-control-container" style="position: fixed; top: 10px; left: 10px; z-index: 9999;">
            <button id="muteToggle5" style="background: none; border: none; cursor: pointer; flex-shrink: 0;">
                <i id="volumeIcon5" class="fas fa-volume-up"></i>
            </button>
            <input type="range" id="volumecontroller5" min="0" max="100" value="100">
        </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = volumeControlHTML;
        document.body.appendChild(container);
        setupVolumeController('muteToggle5', 'volumecontroller5', 'volumeIcon5');
    }
}

// 輔助函數：遞迴查找所有媒體元素，包括 Shadow DOM 中的元素
function findAllMediaElements(rootNode) {
    const mediaElements = [];
    // 查找當前根節點中的媒體元素
    rootNode.querySelectorAll('video, audio').forEach(el => {
        if (!mediaElements.includes(el)) {
            mediaElements.push(el);
        }
    });

    // 查找 Shadow DOM 中的媒體元素
    const allElements = rootNode.querySelectorAll('*');
    allElements.forEach(el => {
        if (el.shadowRoot) {
            findAllMediaElements(el.shadowRoot).forEach(shadowEl => {
                if (!mediaElements.includes(shadowEl)) {
                    mediaElements.push(shadowEl);
                }
            });
        }
    });
    return mediaElements;
}

// 調整音量的輔助函數 - 不再直接調用 updateVolumeBackground
function adjustVolume(value) {
    const elements = findAllMediaElements(document); // 使用新的輔助函數
    
    if (elements.length > 0) { // 確保有找到元素
        elements.forEach(element => {
            if (element) { // 確保元素存在
                element.volume = parseFloat(value) / 100;
            }
        });
        // 不再從這裡調用 updateVolumeBackground
    } else {
        console.warn('No video or audio elements found on the page, including Shadow DOMs.');
    }
}

// 重置音量的輔助函數
function resetVolume() {
    const elements = findAllMediaElements(document); // 使用新的輔助函數
    elements.forEach(element => {
        element.volume = 1.0; // 將音量重置為 100%
    });
}

// 修改後的移除音量控制器函數 (保留這個版本)
function removeVolumeControl() {
    resetVolume(); // 重置音量
    const volumeControl = document.querySelector('.volume-control-container');
    if (volumeControl) {
        volumeControl.remove();
    }
}
