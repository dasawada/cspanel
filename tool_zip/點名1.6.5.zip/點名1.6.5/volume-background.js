// 當使用者切換標籤頁時，檢查並更新狀態
chrome.tabs.onActivated.addListener((activeInfo) => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        const isMuted = tab.mutedInfo.muted;
        if (isMuted) {
            // 禁用或不點亮 toggle 開關
            chrome.storage.local.set({ [`volumeControlEnabled_${activeInfo.tabId}`]: false });
            console.log(`Tab ${activeInfo.tabId} is muted. Volume control is disabled.`);
        } else {
            // 啟用或點亮 toggle 開關
            chrome.storage.local.get(`volumeControlEnabled_${activeInfo.tabId}`, (data) => {
                const isEnabled = data[`volumeControlEnabled_${activeInfo.tabId}`] || false;
                console.log(`Tab ${activeInfo.tabId} volume control enabled: ${isEnabled}`);
            });
        }
    });
});

// 當標籤頁更新時，檢查並更新狀態
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete") {
        const isMuted = tab.mutedInfo.muted;
        if (isMuted) {
            // 禁用或不點亮 toggle 開關
            chrome.storage.local.set({ [`volumeControlEnabled_${tabId}`]: false });
            console.log(`Tab ${tabId} is muted. Volume control is disabled.`);
        } else {
            // 啟用或點亮 toggle 開關
            chrome.storage.local.get(`volumeControlEnabled_${tabId}`, (data) => {
                const isEnabled = data[`volumeControlEnabled_${tabId}`] || false;
                console.log(`Tab ${tabId} volume control enabled: ${isEnabled}`);
            });
        }
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "fetchData") {
        const apiUrl = request.url;
        const requestData = request.data;

        fetch(apiUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(requestData),
        })
            .then((response) => response.json())
            .then((data) => {
                sendResponse({ success: true, data });
            })
            .catch((error) => {
                sendResponse({ success: false, error: error.message });
            });

        return true; // 必須返回 true，允許異步回應
    }
});
