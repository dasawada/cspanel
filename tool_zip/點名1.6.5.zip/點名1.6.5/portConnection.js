let port = null;
let messageQueue = [];
let isConnected = false;

function connect() {
    if (!isConnected) {
        try {
            port = chrome.runtime.connect({name: 'popup'});
            isConnected = true;

            port.onDisconnect.addListener(() => {
                isConnected = false;
                port = null;
                setTimeout(connect, 100);
            });

            port.onMessage.addListener((response) => {
                if (response.type === 'error') {
                    console.log('Received error:', response.error);
                }
            });

            // 處理排隊的消息
            while (messageQueue.length > 0) {
                const {message, callback} = messageQueue.shift();
                sendMessageToBackground(message, callback);
            }
        } catch (e) {
            console.log('Connection failed, retrying...');
            setTimeout(connect, 100);
        }
    }
}

function sendMessageToBackground(message, callback) {
    if (!isConnected) {
        messageQueue.push({message, callback});
        connect();
        return;
    }

    try {
        port.postMessage(message);
        if (callback) {
            port.onMessage.addListener(function listener(response) {
                port.onMessage.removeListener(listener);
                callback(response);
            });
        }
    } catch (e) {
        console.log('Send message failed, reconnecting...');
        isConnected = false;
        connect();
    }
}

// 初始連接
connect();

// 暴露全局API
window.sendMessageToBackground = sendMessageToBackground;
