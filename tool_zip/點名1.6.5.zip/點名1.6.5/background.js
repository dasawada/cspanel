// 添加剪貼板處理
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'copyText') {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      function: (text) => {
        try {
          const textarea = document.createElement('textarea');
          textarea.value = text;
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
          return true;
        } catch (err) {
          console.error('Copy failed:', err);
          return false;
        }
      },
      args: [request.text]
    }).then(results => {
      sendResponse({ success: results[0].result });
    });
    return true;  // 保持消息通道開啟
  }
});

let ports = new Set();

chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'popup') {
        ports.add(port);
        
        port.onMessage.addListener((msg) => {
            try {
                handleMessage(msg, port);
            } catch (error) {
                port.postMessage({
                    type: 'error',
                    error: error.message
                });
            }
        });

        port.onDisconnect.addListener(() => {
            ports.delete(port);
        });
    }
});

function handleMessage(msg, port) {
    // 處理消息的邏輯
    port.postMessage({
        type: 'success',
        data: 'Message received'
    });
}

chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension installed');
});