class MessageManager {
    static async sendMessage(message) {
        return await ErrorHandler.retryOperation(async () => {
            return new Promise((resolve, reject) => {
                try {
                    chrome.runtime.sendMessage(message, response => {
                        const error = chrome.runtime.lastError;
                        if (error) {
                            ErrorHandler.handleRuntimeError(error);
                            resolve(null);
                        } else {
                            resolve(response);
                        }
                    });
                } catch (error) {
                    ErrorHandler.handleRuntimeError(error);
                    resolve(null);
                }
            });
        });
    }

    static addMessageListener(callback) {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            try {
                callback(message, sender, sendResponse);
                return true; // 保持通道開啟
            } catch (error) {
                ErrorHandler.handleRuntimeError(error);
                return false;
            }
        });
    }
}

window.MessageManager = MessageManager;
