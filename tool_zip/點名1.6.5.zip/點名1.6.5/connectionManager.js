class ConnectionManager {
    static port = null;

    static connect() {
        if (!this.port) {
            this.port = chrome.runtime.connect({name: "popup"});
            this.port.onDisconnect.addListener(() => {
                console.log("Port disconnected, attempting reconnect...");
                this.port = null;
                setTimeout(() => this.connect(), 1000);
            });
        }
        return this.port;
    }

    static sendMessage(message) {
        return new Promise((resolve, reject) => {
            const port = this.connect();
            try {
                port.postMessage(message);
                port.onMessage.addListener(function listener(response) {
                    port.onMessage.removeListener(listener);
                    resolve(response);
                });
            } catch (error) {
                console.error("Message send error:", error);
                resolve(null);
            }
        });
    }
}

window.ConnectionManager = ConnectionManager;
