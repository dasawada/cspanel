(function () {
    // 定義目標選擇器與條件
    const selector = '.MuiTableCell-root.MuiTableCell-body.MuiTableCell-sizeMedium.css-zy3sbh';
    const timeRegex = /\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}-\d{2}:\d{2}/;
    const weekdays = ['日', '一', '二', '三', '四', '五', '六'];

    // 定義更新函數
    function updateElements() {
        let found = false; // 標記是否找到目標元素
        document.querySelectorAll(selector).forEach(element => {
            const text = element.textContent.trim(); // 確保內容沒有多餘空格
            const match = timeRegex.exec(text);

            // 確保不重複更新
            if (match && !element.dataset.updated) {
                const [datePart, timePart] = match[0].split(' ');
                const day = new Date(datePart).getDay(); // 計算星期
                const weekday = weekdays[day];
                const newText = `${datePart} (${weekday}) ${timePart}`;
                element.textContent = newText; // 更新元素內容
                element.dataset.updated = "true"; // 標記為已更新
                console.log('已更新元素:', newText);
                found = true;
            }
        });
        return found;
    }

    // 使用 MutationObserver 監聽
    const observer = new MutationObserver(() => {
        updateElements(); // 無論找到與否都繼續監聽
    });

    // 初次檢查
    updateElements(); // 初始更新

    // 持續監聽 DOM 變化
    observer.observe(document.body, { childList: true, subtree: true });
    console.log('監聽已啟動，等待動態元素更新。');
})();
